//
//  AppDelegate.h
//  testApp
//
//  Created by Kevin O'Toole on 10/5/13.
//  Copyright (c) 2013 Kevin O'Toole. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
