//
//  AppDelegate.h
//  testApp
//
//  Created by Kevin O'Toole on 10/8/13.
//  AOC1 1310 Week2 Project
//  Copyright (c) 2013 Kevin O'Toole. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
